package com.autocapture360.a34.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

class RotationTracker(context: Context) : SensorEventListener {
    interface Listener {
        fun onRotationUpdated(angleDeg: Double, speedDegPerSec: Double, direction: Int)
    }

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private var listener: Listener? = null
    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private var haveGravity = false
    private var haveMag = false
    private val rotationMatrix = FloatArray(9)
    private val orientation = FloatArray(3)

    @Volatile private var running = false
    @Volatile private var signedAngleDeg = 0.0
    @Volatile private var speedDegPerSec = 0.0
    @Volatile private var direction = 0
    private var lastTimestampNs = 0L
    private var startTimestampMs = 0L
    private var gyroBias = 0.0
    private var lastMagRelative = 0.0
    private var magAccumulated = 0.0
    private var lastMagRaw = Double.NaN
    private var lastUiEmitMs = 0L
    private val latestGyro = FloatArray(3)
    private val latestAccel = FloatArray(3)
    private val latestMag = FloatArray(3)

    fun hasRequiredSensors(): Boolean = gyro != null && accelerometer != null
    fun hasMagnetometer(): Boolean = magnetometer != null

    fun setListener(listener: Listener?) { this.listener = listener }

    @Synchronized
    fun start() {
        if (running) return
        if (!hasRequiredSensors()) throw IllegalStateException("Gyroscope/accelerometer missing")
        signedAngleDeg = 0.0
        speedDegPerSec = 0.0
        direction = 0
        gyroBias = 0.0
        haveGravity = false
        haveMag = false
        lastTimestampNs = 0L
        startTimestampMs = SystemClock.elapsedRealtime()
        lastMagRaw = Double.NaN
        magAccumulated = 0.0
        sensorManager.registerListener(this, gyro, SensorManager.SENSOR_DELAY_FASTEST)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        magnetometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        running = true
        android.util.Log.d("AutoCapture360", "ROTATION_START")
    }

    @Synchronized
    fun stop() {
        if (!running) return
        sensorManager.unregisterListener(this)
        running = false
        android.util.Log.d("AutoCapture360", "ROTATION_STOP angle=${signedAngleDeg}")
    }

    fun elapsedMs(): Long = if (startTimestampMs == 0L) 0L else SystemClock.elapsedRealtime() - startTimestampMs
    fun getSignedAngleDeg(): Double = signedAngleDeg
    fun getAbsoluteProgressDeg(): Double = abs(signedAngleDeg)
    fun getSpeedDegPerSec(): Double = speedDegPerSec
    fun getDirection(): Int = direction
    fun isRunning(): Boolean = running

    data class Snapshot(
        val gyro: FloatArray,
        val accelerometer: FloatArray,
        val magnetometer: FloatArray,
        val angleDeg: Double,
        val speedDegPerSec: Double,
        val direction: Int
    )

    @Synchronized
    fun snapshot(): Snapshot = Snapshot(
        latestGyro.copyOf(),
        latestAccel.copyOf(),
        latestMag.copyOf(),
        signedAngleDeg,
        speedDegPerSec,
        direction
    )

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> updateGravity(event.values)
            Sensor.TYPE_MAGNETIC_FIELD -> updateMag(event.values)
            Sensor.TYPE_GYROSCOPE -> updateGyro(event)
        }
    }

    private fun updateGravity(values: FloatArray) {
        synchronized(this) { for (i in 0..2) latestAccel[i] = values[i] }
        val alpha = 0.92f
        if (!haveGravity) {
            for (i in 0..2) gravity[i] = values[i]
            haveGravity = true
            return
        }
        for (i in 0..2) gravity[i] = alpha * gravity[i] + (1f - alpha) * values[i]
    }

    private fun updateMag(values: FloatArray) {
        synchronized(this) { for (i in 0..2) latestMag[i] = values[i] }
        val alpha = 0.75f
        if (!haveMag) {
            for (i in 0..2) magnetic[i] = values[i]
            haveMag = true
            return
        }
        for (i in 0..2) magnetic[i] = alpha * magnetic[i] + (1f - alpha) * values[i]
    }

    private fun updateGyro(event: SensorEvent) {
        synchronized(this) { for (i in 0..2) latestGyro[i] = event.values[i] }
        if (!running || !haveGravity || lastTimestampNs == 0L) {
            lastTimestampNs = event.timestamp
            return
        }
        val dt = ((event.timestamp - lastTimestampNs) * 1e-9).coerceIn(0.0001, 0.1)
        lastTimestampNs = event.timestamp

        val gx = event.values[0].toDouble()
        val gy = event.values[1].toDouble()
        val gz = event.values[2].toDouble()

        val gNorm = sqrt((gravity[0] * gravity[0] + gravity[1] * gravity[1] + gravity[2] * gravity[2]).toDouble()).coerceAtLeast(0.001)
        val ux = gravity[0] / gNorm
        val uy = gravity[1] / gNorm
        val uz = gravity[2] / gNorm
        val verticalRadPerSec = gx * ux + gy * uy + gz * uz
        var verticalDegPerSec = Math.toDegrees(verticalRadPerSec)

        val stationary = abs(verticalDegPerSec) < 1.2 && abs(event.values[0]) < 0.15 && abs(event.values[1]) < 0.15 && abs(event.values[2]) < 0.15
        if (stationary) {
            gyroBias = gyroBias * 0.995 + verticalDegPerSec * 0.005
        }
        verticalDegPerSec -= gyroBias
        speedDegPerSec = verticalDegPerSec
        signedAngleDeg += verticalDegPerSec * dt

        if (abs(verticalDegPerSec) > 0.8) direction = if (verticalDegPerSec > 0) 1 else -1
        if (haveMag && abs(verticalDegPerSec) < 25.0) applyGentleMagnetometerCorrection()

        val now = SystemClock.elapsedRealtime()
        if (now - lastUiEmitMs >= 50L) {
            lastUiEmitMs = now
            listener?.onRotationUpdated(signedAngleDeg, verticalDegPerSec, direction)
        }
    }

    private fun applyGentleMagnetometerCorrection() {
        if (!SensorManager.getRotationMatrix(rotationMatrix, null, gravity, magnetic)) return
        SensorManager.getOrientation(rotationMatrix, orientation)
        val rawDeg = Math.toDegrees(orientation[0].toDouble())
        if (lastMagRaw.isNaN()) {
            lastMagRaw = rawDeg
            lastMagRelative = 0.0
            magAccumulated = 0.0
            return
        }
        var delta = rawDeg - lastMagRaw
        if (delta > 180) delta -= 360.0
        if (delta < -180) delta += 360.0
        if (abs(delta) < 8.0) magAccumulated += delta
        lastMagRaw = rawDeg
        val magneticRelative = magAccumulated
        // Very gentle correction. The magnetometer is deliberately not trusted during fast vibration.
        signedAngleDeg = signedAngleDeg * 0.995 + magneticRelative * 0.005
    }
}
