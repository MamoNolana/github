package com.autocapture360.a34.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.autocapture360.a34.R
import com.autocapture360.a34.sensors.RotationTracker
import com.autocapture360.a34.vibration.A34VibrationController

class DiagnosticsActivity : AppCompatActivity() {
    private lateinit var tracker: RotationTracker
    private lateinit var vibration: A34VibrationController
    private lateinit var gyroText: android.widget.TextView
    private lateinit var accelText: android.widget.TextView
    private lateinit var magText: android.widget.TextView
    private lateinit var rotationText: android.widget.TextView
    private lateinit var profileText: android.widget.TextView
    private val handler = Handler(Looper.getMainLooper())

    private val updater = object : Runnable {
        override fun run() {
            if (isFinishing) return
            val s = tracker.snapshot()
            gyroText.text = "Gyroscope\nX: %.4f\nY: %.4f\nZ: %.4f".format(s.gyro[0], s.gyro[1], s.gyro[2])
            accelText.text = "Accelerometer\nX: %.3f\nY: %.3f\nZ: %.3f".format(s.accelerometer[0], s.accelerometer[1], s.accelerometer[2])
            magText.text = "Magnetometer\nX: %.2f\nY: %.2f\nZ: %.2f".format(s.magnetometer[0], s.magnetometer[1], s.magnetometer[2])
            val dir = when (s.direction) { 1 -> "CW/positive"; -1 -> "CCW/negative"; else -> "не определено" }
            rotationText.text = "Current angle: %.1f°\nRotation speed: %.1f °/s\nDirection: %s".format(s.angleDeg, s.speedDegPerSec, dir)
            profileText.text = "Vibration profile: ${vibration.currentProfile().label}\nRunning: ${vibration.isRunning()}"
            handler.postDelayed(this, 100L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostics)
        gyroText = findViewById(R.id.gyroText)
        accelText = findViewById(R.id.accelText)
        magText = findViewById(R.id.magText)
        rotationText = findViewById(R.id.rotationText)
        profileText = findViewById(R.id.vibrationProfileText)
        tracker = RotationTracker(this)
        vibration = A34VibrationController(this)
        tracker.start()
        handler.post(updater)
    }

    override fun onPause() {
        handler.removeCallbacksAndMessages(null)
        tracker.stop()
        vibration.stop()
        super.onPause()
    }

    override fun onDestroy() {
        tracker.stop()
        vibration.stop()
        super.onDestroy()
    }
}
