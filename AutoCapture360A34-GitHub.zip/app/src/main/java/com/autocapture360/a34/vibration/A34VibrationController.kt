package com.autocapture360.a34.vibration

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

class A34VibrationController(context: Context) {
    enum class Profile(val label: String, val onMs: Long, val offMs: Long) {
        PROFILE_1("Profile 1", 100, 20),
        PROFILE_2("Profile 2", 150, 20),
        PROFILE_3("Profile 3", 200, 30),
        PROFILE_4("Profile 4", 80, 10)
    }

    enum class Direction { AUTO, CLOCKWISE, COUNTERCLOCKWISE }

    private val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(VibratorManager::class.java)
        manager.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    @Volatile private var running = false
    private var currentProfile = Profile.PROFILE_1
    private var strengthPercent = 70

    fun isAvailable(): Boolean = vibrator.hasVibrator()

    @Synchronized
    fun start(profile: Profile = currentProfile, strengthPercent: Int = this.strengthPercent) {
        if (!isAvailable()) {
            Log.e("AutoCapture360", "ERROR: VIBRATOR_UNAVAILABLE")
            return
        }
        this.currentProfile = profile
        this.strengthPercent = strengthPercent.coerceIn(1, 100)
        val on = profile.onMs.coerceAtLeast(1L)
        val off = profile.offMs.coerceAtLeast(0L)
        val amplitude = (255 * this.strengthPercent / 100f).toInt().coerceIn(1, 255)
        val timings = longArrayOf(0L, on, off)
        val amplitudes = intArrayOf(0, amplitude, 0)
        val effect = VibrationEffect.createWaveform(timings, amplitudes, 0)
        vibrator.vibrate(effect)
        running = true
        Log.d("AutoCapture360", "VIBRATION_START profile=${profile.label} strength=${this.strengthPercent}% on=$on off=$off")
    }

    @Synchronized
    fun startCustom(onMs: Long, offMs: Long, strengthPercent: Int) {
        if (!isAvailable()) return
        val amplitude = (255 * strengthPercent.coerceIn(1, 100) / 100f).toInt().coerceIn(1, 255)
        vibrator.vibrate(
            VibrationEffect.createWaveform(
                longArrayOf(0L, onMs.coerceIn(1, 1000), offMs.coerceIn(0, 1000)),
                intArrayOf(0, amplitude, 0),
                0
            )
        )
        running = true
        Log.d("AutoCapture360", "VIBRATION_START custom strength=$strengthPercent% on=$onMs off=$offMs")
    }

    @Synchronized
    fun stop() {
        vibrator.cancel()
        if (running) Log.d("AutoCapture360", "VIBRATION_STOP")
        running = false
    }

    fun isRunning(): Boolean = running
    fun currentProfile(): Profile = currentProfile
    fun setProfile(profile: Profile) { currentProfile = profile }
    fun setStrength(percent: Int) { strengthPercent = percent.coerceIn(1, 100) }
}
