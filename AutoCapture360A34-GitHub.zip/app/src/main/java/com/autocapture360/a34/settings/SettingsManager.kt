package com.autocapture360.a34.settings

import android.content.Context

class SettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var vibrationStrength: Int
        get() = prefs.getInt("vibrationStrength", 70)
        set(value) = prefs.edit().putInt("vibrationStrength", value.coerceIn(1, 100)).apply()

    var pulseDurationMs: Long
        get() = prefs.getLong("pulseDurationMs", 100L)
        set(value) = prefs.edit().putLong("pulseDurationMs", value.coerceIn(20L, 1000L)).apply()

    var pauseDurationMs: Long
        get() = prefs.getLong("pauseDurationMs", 20L)
        set(value) = prefs.edit().putLong("pauseDurationMs", value.coerceIn(0L, 1000L)).apply()

    var startDelayMs: Long
        get() = prefs.getLong("startDelayMs", 2000L)
        set(value) = prefs.edit().putLong("startDelayMs", value.coerceIn(0L, 10000L)).apply()

    var direction: String
        get() = prefs.getString("direction", "AUTO") ?: "AUTO"
        set(value) = prefs.edit().putString("direction", value).apply()

    var preferUltraWide: Boolean
        get() = prefs.getBoolean("preferUltraWide", false)
        set(value) = prefs.edit().putBoolean("preferUltraWide", value).apply()

    var framesPer360: Int
        get() = prefs.getInt("framesPer360", 18)
        set(value) = prefs.edit().putInt("framesPer360", value.coerceIn(12, 24)).apply()

    var maxRotationTimeMs: Long
        get() = 30_000L
        set(_) {}
}
