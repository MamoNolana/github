package com.autocapture360.a34

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.autocapture360.a34.camera.CameraController
import com.autocapture360.a34.panorama.PanoramaStitcher
import com.autocapture360.a34.sensors.RotationTracker
import com.autocapture360.a34.settings.SettingsManager
import com.autocapture360.a34.vibration.A34VibrationController
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

class AutoCaptureController(
    private val camera: CameraController,
    private val vibration: A34VibrationController,
    private val tracker: RotationTracker,
    private val settings: SettingsManager,
    private val panoramaStitcher: PanoramaStitcher,
    private val cacheDir: File,
    private val listener: Listener
) {
    interface Listener {
        fun onUi(angle: Double, speed: Double, direction: Int, frameCount: Int, vibrationOn: Boolean)
        fun onStatus(text: String)
        fun onFinished(panorama: File?, frames: List<File>, panoramaUri: android.net.Uri?, error: String?)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val frames = mutableListOf<File>()
    private var running = false
    private var capturing = false
    private var nextTarget = 0.0
    private var directionSign = 0
    private var lastCaptureMs = 0L
    private var startedMs = 0L
    private var currentProfile = A34VibrationController.Profile.PROFILE_1
    private var poller: Runnable? = null

    fun isRunning(): Boolean = running

    fun start() {
        if (running) return
        if (!tracker.hasRequiredSensors()) {
            listener.onFinished(null, emptyList(), null, "Отсутствует гироскоп или акселерометр.")
            return
        }
        if (!vibration.isAvailable()) {
            listener.onFinished(null, emptyList(), null, "Вибромотор недоступен для Android API.")
            return
        }
        frames.clear()
        capturing = false
        nextTarget = 0.0
        directionSign = 0
        lastCaptureMs = 0L
        startedMs = System.currentTimeMillis()
        currentProfile = vibration.currentProfile()
        running = true
        tracker.start()
        listener.onStatus("Подготовка… 2 секунды. Не двигайте телефон.")
        schedulePoller()
        handler.postDelayed({
            if (!running) return@postDelayed
            listener.onStatus("Съёмка начинается. Первый кадр — исходная точка.")
            captureFrame { 
                if (running) startConfiguredVibration()
                listener.onStatus("Вибромотор включён. Ожидаю фактическое вращение.")
            }
        }, settings.startDelayMs)
    }

    private fun startConfiguredVibration() {
        if (!running) return
        val profileMatches = currentProfile.onMs == settings.pulseDurationMs && currentProfile.offMs == settings.pauseDurationMs
        if (profileMatches) {
            vibration.start(currentProfile, settings.vibrationStrength)
        } else {
            vibration.startCustom(settings.pulseDurationMs, settings.pauseDurationMs, settings.vibrationStrength)
        }
    }

    private fun schedulePoller() {
        val task = object : Runnable {
            override fun run() {
                if (!running) return
                processMotion()
                listener.onUi(tracker.getAbsoluteProgressDeg(), tracker.getSpeedDegPerSec(), tracker.getDirection(), frames.size, vibration.isRunning())
                handler.postDelayed(this, 30L)
            }
        }
        poller = task
        handler.post(task)
    }

    private fun processMotion() {
        val elapsed = System.currentTimeMillis() - startedMs
        if (elapsed >= settings.maxRotationTimeMs) {
            timeout()
            return
        }

        val signed = tracker.getSignedAngleDeg()
        if (directionSign == 0 && abs(signed) >= 5.0) directionSign = if (signed >= 0) 1 else -1
        if (directionSign != 0 && settings.direction != "AUTO") {
            val expected = if (settings.direction == "CLOCKWISE") 1 else -1
            if (tracker.getDirection() != 0 && tracker.getDirection() != expected && tracker.getAbsoluteProgressDeg() < 15.0) {
                fail("Телефон вращается в выбранном направлении наоборот. Измените настройку направления.")
                return
            }
        }
        if (directionSign == 0 || capturing) return

        val progress = signed * directionSign
        val speed = abs(tracker.getSpeedDegPerSec())
        if (progress >= 357.5) {
            finishRotation()
            return
        }

        val step = 360.0 / settings.framesPer360.toDouble()
        if (nextTarget == 0.0) nextTarget = step
        val distance = nextTarget - progress
        val brakingWindow = max(2.0, speed * 0.18)

        // Stop the motor shortly before the target so the phone can coast to a steadier speed.
        if (vibration.isRunning() && distance <= brakingWindow && distance > -2.0) {
            vibration.stop()
            listener.onStatus("Стабилизация на ${nextTarget.toInt()}°. Скорость ${speed.toInt()} °/с")
        }

        if (!vibration.isRunning() && progress >= nextTarget - 2.5 && speed <= 35.0 && System.currentTimeMillis() - lastCaptureMs >= 500L) {
            captureFrame {
                lastCaptureMs = System.currentTimeMillis()
                nextTarget += step
                if (running && nextTarget < 355.0) {
                    handler.postDelayed({ if (running) startConfiguredVibration() }, 180L)
                }
            }
        }
    }

    private fun captureFrame(after: () -> Unit) {
        if (!running || capturing) return
        capturing = true
        camera.captureToCache({ file ->
            val index = frames.size
            val galleryName = String.format("AC_%03d.jpg", index)
            camera.saveJpegToGallery(file, galleryName)
            frames.add(file)
            listener.onUi(tracker.getAbsoluteProgressDeg(), tracker.getSpeedDegPerSec(), tracker.getDirection(), frames.size, false)
            capturing = false
            after()
        }, { error ->
            capturing = false
            fail("Ошибка камеры: ${error.message ?: "неизвестная ошибка"}")
        })
    }

    private fun finishRotation() {
        if (!running) return
        running = false
        vibration.stop()
        tracker.stop()
        poller?.let { handler.removeCallbacks(it) }
        listener.onStatus("Полный оборот обнаружен. Склеиваю ${frames.size} кадров…")
        worker.execute {
            var result: File? = null
            var error: String? = null
            var panoramaUri: android.net.Uri? = null
            try {
                if (frames.size < 8) throw IllegalStateException("Слишком мало кадров для надёжной склейки (${frames.size}).")
                result = panoramaStitcher.stitch(frames, File(cacheDir, "panorama" )).file
                panoramaUri = camera.saveJpegToGallery(result, result.name)
            } catch (t: Throwable) {
                Log.e("AutoCapture360", "ERROR panorama", t)
                error = when (t) {
                    is PanoramaStitcher.StitchException -> "OpenCV не смог сопоставить кадры (код ${t.status}). Попробуйте больше текстур на сцене и равномерное вращение."
                    else -> "Не удалось создать панораму: ${t.message}"
                }
            }
            val finalResult = result
            val finalError = error
            val finalUri = panoramaUri
            handler.post { listener.onFinished(finalResult, frames.toList(), finalUri, finalError) }
        }
    }

    private fun timeout() {
        Log.e("AutoCapture360", "ROTATION_TIMEOUT")
        fail("Не удалось завершить полный оборот. Попробуйте другую поверхность или настройки вибрации.")
    }

    fun stop(reason: String = "Остановлено пользователем") {
        if (!running) {
            vibration.stop()
            tracker.stop()
            return
        }
        running = false
        poller?.let { handler.removeCallbacks(it) }
        vibration.stop()
        tracker.stop()
        capturing = false
        listener.onStatus(reason)
        listener.onFinished(null, frames.toList(), null, reason)
    }

    private fun fail(message: String) {
        Log.e("AutoCapture360", "ERROR $message")
        running = false
        poller?.let { handler.removeCallbacks(it) }
        vibration.stop()
        tracker.stop()
        listener.onFinished(null, frames.toList(), null, message)
    }

    fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        worker.shutdownNow()
        vibration.stop()
        tracker.stop()
    }
}
