package com.autocapture360.a34.calibration

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.autocapture360.a34.sensors.RotationTracker
import com.autocapture360.a34.settings.SettingsManager
import com.autocapture360.a34.vibration.A34VibrationController
import kotlin.math.abs

class CalibrationController(
    private val vibration: A34VibrationController,
    private val tracker: RotationTracker,
    private val settings: SettingsManager
) {
    data class Result(
        val profile: A34VibrationController.Profile,
        val degrees: Double,
        val meanSpeed: Double,
        val speedStdDev: Double,
        val direction: Int
    ) {
        val stabilityRatio: Double get() = if (meanSpeed > 0.01) speedStdDev / meanSpeed else Double.POSITIVE_INFINITY
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var running = false

    fun testProfile(profile: A34VibrationController.Profile, durationMs: Long = 5_000L, callback: (Result) -> Unit) {
        if (running) return
        if (!tracker.hasRequiredSensors() || !vibration.isAvailable()) return
        running = true
        settingsRun(profile, durationMs, callback)
    }

    private fun settingsRun(profile: A34VibrationController.Profile, durationMs: Long, callback: (Result) -> Unit) {
        val samples = mutableListOf<Double>()
        tracker.setListener(object : RotationTracker.Listener {
            override fun onRotationUpdated(angleDeg: Double, speedDegPerSec: Double, direction: Int) {
                synchronized(samples) { samples.add(abs(speedDegPerSec)) }
            }
        })
        tracker.start()
        vibration.start(profile, settings.vibrationStrength)
        mainHandler.postDelayed({
            vibration.stop()
            tracker.stop()
            tracker.setListener(null)
            val degrees = tracker.getAbsoluteProgressDeg()
            val mean = synchronized(samples) { if (samples.isEmpty()) 0.0 else samples.average() }
            val std = synchronized(samples) {
                if (samples.size < 2) 0.0 else kotlin.math.sqrt(samples.map { (it - mean) * (it - mean) }.average())
            }
            val result = Result(profile, degrees, mean, std, tracker.getDirection())
            Log.d("AutoCapture360", "CALIBRATION ${profile.label} degrees=${degrees.toInt()} mean=${mean.toInt()} std=${std.toInt()} direction=${result.direction}")
            running = false
            callback(result)
        }, durationMs)
    }

    fun findBest(profiles: List<A34VibrationController.Profile>, callback: (List<Result>, Result?) -> Unit) {
        if (running) return
        val results = mutableListOf<Result>()
        fun next(index: Int) {
            if (index >= profiles.size) {
                // Prefer a profile with enough movement and the lowest normalized speed variation.
                val eligible = results.filter { it.degrees >= 10.0 && it.meanSpeed >= 1.0 }
                val best = eligible.minByOrNull { it.stabilityRatio }
                callback(results.toList(), best)
                return
            }
            testProfile(profiles[index], 4_000L) {
                results.add(it)
                mainHandler.postDelayed({ next(index + 1) }, 400L)
            }
        }
        next(0)
    }

    fun stop() {
        running = false
        mainHandler.removeCallbacksAndMessages(null)
        vibration.stop()
        tracker.stop()
        tracker.setListener(null)
    }
}
