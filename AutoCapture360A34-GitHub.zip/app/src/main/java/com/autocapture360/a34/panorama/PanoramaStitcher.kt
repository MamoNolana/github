package com.autocapture360.a34.panorama

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.imgproc.Imgproc
import org.opencv.stitching.Stitcher
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PanoramaStitcher {
    data class Result(val file: File, val status: Int)

    fun stitch(sourceFiles: List<File>, outputDir: File): Result {
        require(sourceFiles.size >= 3) { "Need at least 3 frames" }
        Log.d("AutoCapture360", "STITCHING_START frames=${sourceFiles.size}")
        val mats = ArrayList<Mat>(sourceFiles.size)
        try {
            for (file in sourceFiles) {
                val src = Imgcodecs.imread(file.absolutePath, Imgcodecs.IMREAD_COLOR)
                if (src.empty()) throw IllegalStateException("Cannot read ${file.name}")
                val resized = resizeForStitching(src, 1800)
                if (resized.dataAddr() != src.dataAddr()) src.release()
                mats.add(resized)
            }

            val stitcher = Stitcher.create(Stitcher.PANORAMA)
            stitcher.setRegistrationResol(0.6)
            stitcher.setSeamEstimationResol(0.12)
            stitcher.setCompositingResol(20.0)
            stitcher.setPanoConfidenceThresh(0.5)
            stitcher.setWaveCorrection(true)

            val pano = Mat()
            val status = stitcher.stitch(mats, pano)
            if (status != Stitcher.OK || pano.empty()) {
                Log.e("AutoCapture360", "ERROR stitching status=$status")
                throw StitchException(status)
            }

            if (!outputDir.exists()) outputDir.mkdirs()
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val output = File(outputDir, "AutoCapture360_$timestamp.jpg")
            if (!Imgcodecs.imwrite(output.absolutePath, pano)) {
                throw IllegalStateException("Failed to write panorama")
            }
            pano.release()
            Log.d("AutoCapture360", "STITCHING_DONE ${output.absolutePath}")
            return Result(output, status)
        } finally {
            mats.forEach { it.release() }
        }
    }

    private fun resizeForStitching(src: Mat, maxDimension: Int): Mat {
        val largest = maxOf(src.width(), src.height())
        if (largest <= maxDimension) return src.clone()
        val scale = maxDimension.toDouble() / largest.toDouble()
        val dst = Mat()
        Imgproc.resize(src, dst, Size(src.width() * scale, src.height() * scale), 0.0, 0.0, Imgproc.INTER_AREA)
        return dst
    }

    class StitchException(val status: Int) : RuntimeException("OpenCV Stitcher status=$status")
}
