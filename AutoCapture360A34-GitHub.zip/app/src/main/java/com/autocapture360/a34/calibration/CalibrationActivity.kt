package com.autocapture360.a34.calibration

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.autocapture360.a34.R
import com.autocapture360.a34.sensors.RotationTracker
import com.autocapture360.a34.settings.SettingsManager
import com.autocapture360.a34.vibration.A34VibrationController

class CalibrationActivity : AppCompatActivity() {
    private lateinit var controller: CalibrationController
    private lateinit var p1: TextView
    private lateinit var p2: TextView
    private lateinit var p3: TextView
    private lateinit var p4: TextView
    private lateinit var best: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calibration)
        val vibration = A34VibrationController(this)
        val tracker = RotationTracker(this)
        val settings = SettingsManager(this)
        controller = CalibrationController(vibration, tracker, settings)

        p1 = findViewById(R.id.profile1Result)
        p2 = findViewById(R.id.profile2Result)
        p3 = findViewById(R.id.profile3Result)
        p4 = findViewById(R.id.profile4Result)
        best = findViewById(R.id.customSettingsText)

        val mapping = listOf(
            findViewById<Button>(R.id.profile1Button) to Pair(A34VibrationController.Profile.PROFILE_1, p1),
            findViewById<Button>(R.id.profile2Button) to Pair(A34VibrationController.Profile.PROFILE_2, p2),
            findViewById<Button>(R.id.profile3Button) to Pair(A34VibrationController.Profile.PROFILE_3, p3),
            findViewById<Button>(R.id.profile4Button) to Pair(A34VibrationController.Profile.PROFILE_4, p4)
        )
        mapping.forEach { (button, pair) ->
            button.setOnClickListener {
                button.isEnabled = false
                pair.second.text = "Тест 5 секунд…"
                controller.testProfile(pair.first, 5_000L) { result ->
                    pair.second.text = format(result)
                    button.isEnabled = true
                }
            }
        }

        findViewById<Button>(R.id.findBestButton).setOnClickListener { button ->
            button.isEnabled = false
            best.text = "Ищу измеренно наиболее стабильный профиль…"
            controller.findBest(A34VibrationController.Profile.entries) { results, selected ->
                results.forEach { r ->
                    val out = when (r.profile) {
                        A34VibrationController.Profile.PROFILE_1 -> p1
                        A34VibrationController.Profile.PROFILE_2 -> p2
                        A34VibrationController.Profile.PROFILE_3 -> p3
                        A34VibrationController.Profile.PROFILE_4 -> p4
                    }
                    out.text = format(r)
                }
                best.text = if (selected == null) {
                    "Нет профиля с достаточным вращением. Выберите другую поверхность."
                } else {
                    "Лучший по измеренной стабильности: ${selected.profile.label}. Это измеренный результат данного теста, не гарантия для других поверхностей."
                }
                button.isEnabled = true
            }
        }
    }

    private fun format(r: CalibrationController.Result): String {
        val direction = when (r.direction) { 1 -> "положительное"; -1 -> "отрицательное"; else -> "не определено" }
        return "5 с: ${r.degrees.toInt()}°; средняя скорость ${r.meanSpeed.toInt()} °/с; разброс ${r.speedStdDev.toInt()} °/с; направление $direction"
    }

    override fun onPause() {
        controller.stop()
        super.onPause()
    }
}
