package com.autocapture360.a34

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.autocapture360.a34.calibration.CalibrationActivity
import com.autocapture360.a34.camera.CameraController
import com.autocapture360.a34.panorama.PanoramaStitcher
import com.autocapture360.a34.sensors.RotationTracker
import com.autocapture360.a34.settings.SettingsManager
import com.autocapture360.a34.ui.DiagnosticsActivity
import com.autocapture360.a34.vibration.A34VibrationController
import org.opencv.android.OpenCVLoader
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity(), RotationTracker.Listener, CameraController.Listener, AutoCaptureController.Listener {
    private lateinit var previewView: androidx.camera.view.PreviewView
    private lateinit var statusText: TextView
    private lateinit var framesText: TextView
    private lateinit var angleText: TextView
    private lateinit var speedText: TextView
    private lateinit var vibrationText: TextView
    private lateinit var resultText: TextView
    private lateinit var startButton: android.widget.Button
    private lateinit var stopButton: android.widget.Button
    private lateinit var showPanoramaButton: android.widget.Button
    private lateinit var savePanoramaButton: android.widget.Button
    private lateinit var newCaptureButton: android.widget.Button

    private lateinit var settings: SettingsManager
    private lateinit var vibration: A34VibrationController
    private lateinit var tracker: RotationTracker
    private lateinit var camera: CameraController
    private lateinit var stitcher: PanoramaStitcher
    private lateinit var controller: AutoCaptureController

    private var lastPanorama: File? = null
    private var lastPanoramaUri: Uri? = null
    private var cameraStarted = false
    private val uiHandler = Handler(Looper.getMainLooper())

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val cameraGranted = grants[Manifest.permission.CAMERA] == true || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        if (cameraGranted) startCamera() else {
            statusText.text = "Нужен доступ к камере для автоматической съёмки."
            startButton.isEnabled = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()

        settings = SettingsManager(this)
        vibration = A34VibrationController(this)
        tracker = RotationTracker(this).also { it.setListener(this) }
        camera = CameraController(this).also { it.setListener(this) }
        stitcher = PanoramaStitcher()
        controller = AutoCaptureController(camera, vibration, tracker, settings, stitcher, cacheDir, this)

        if (!OpenCVLoader.initLocal()) {
            resultText.text = "Ошибка: OpenCV не загрузился."
        }

        startButton.setOnClickListener { startCapture() }
        stopButton.setOnClickListener { controller.stop("Остановлено пользователем") }
        findViewById<View>(R.id.calibrationButton).setOnClickListener {
            startActivity(Intent(this, CalibrationActivity::class.java))
        }
        findViewById<View>(R.id.diagnosticsButton).setOnClickListener {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }
        findViewById<View>(R.id.settingsButton).setOnClickListener { showSettingsDialog() }
        showPanoramaButton.setOnClickListener { showPanorama() }
        savePanoramaButton.setOnClickListener { savePanoramaAgain() }
        newCaptureButton.setOnClickListener { resetUi() }
        stopButton.isEnabled = false

        requestPermissionsIfNeeded()
    }

    private fun bindViews() {
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        framesText = findViewById(R.id.framesText)
        angleText = findViewById(R.id.angleText)
        speedText = findViewById(R.id.speedText)
        vibrationText = findViewById(R.id.vibrationText)
        resultText = findViewById(R.id.resultText)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        showPanoramaButton = findViewById(R.id.showPanoramaButton)
        savePanoramaButton = findViewById(R.id.savePanoramaButton)
        newCaptureButton = findViewById(R.id.newCaptureButton)
    }

    private fun requestPermissionsIfNeeded() {
        val missing = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (missing.isEmpty()) startCamera() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startCamera() {
        if (cameraStarted) return
        cameraStarted = true
        statusText.text = "Готово. Положите телефон на гладкую поверхность."
        camera.start(previewView, settings.preferUltraWide)
    }

    private fun startCapture() {
        if (!cameraStarted) return
        lastPanorama = null
        lastPanoramaUri = null
        resultText.text = ""
        showPanoramaButton.visibility = View.GONE
        savePanoramaButton.visibility = View.GONE
        newCaptureButton.visibility = View.GONE
        startButton.isEnabled = false
        stopButton.isEnabled = true
        controller.start()
    }

    override fun onRotationUpdated(angleDeg: Double, speedDegPerSec: Double, direction: Int) {
        uiHandler.post {
            updateMotion(angleDeg, speedDegPerSec, direction)
        }
    }

    override fun onUi(angle: Double, speed: Double, direction: Int, frameCount: Int, vibrationOn: Boolean) {
        framesText.text = "Кадры: $frameCount"
        angleText.text = "Угол: ${angle.toInt()}° / 360°"
        speedText.text = "Скорость: ${String.format(Locale.US, "%.1f", speed)} °/с"
        vibrationText.text = "Вибромотор: ${if (vibrationOn) "вкл." else "выкл."}"
    }

    private fun updateMotion(angle: Double, speed: Double, direction: Int) {
        if (controller.isRunning()) {
            angleText.text = "Угол: ${kotlin.math.abs(angle).toInt()}° / 360°"
            speedText.text = "Скорость: ${String.format(Locale.US, "%.1f", kotlin.math.abs(speed))} °/с"
            vibrationText.text = "Вибромотор: ${if (vibration.isRunning()) "вкл." else "выкл."}"
        }
    }

    override fun onStatus(text: String) {
        statusText.text = text
    }

    override fun onFinished(panorama: File?, frames: List<File>, panoramaUri: Uri?, error: String?) {
        startButton.isEnabled = true
        stopButton.isEnabled = false
        vibration.stop()
        tracker.stop()
        onUi(tracker.getAbsoluteProgressDeg(), tracker.getSpeedDegPerSec(), tracker.getDirection(), frames.size, false)
        if (error != null) {
            statusText.text = error
            resultText.text = "Исходные кадры сохранены: ${frames.size}"
            showPanoramaButton.visibility = View.GONE
            savePanoramaButton.visibility = View.GONE
            newCaptureButton.visibility = View.VISIBLE
            return
        }
        lastPanorama = panorama
        lastPanoramaUri = panoramaUri
        statusText.text = "Готово"
        resultText.text = "Создана панорама из ${frames.size} кадров. Исходники сохранены в Pictures/AutoCapture360."
        showPanoramaButton.visibility = View.VISIBLE
        savePanoramaButton.visibility = View.VISIBLE
        newCaptureButton.visibility = View.VISIBLE
    }

    override fun onCameraReady(mainCameraAvailable: Boolean, ultraWideAvailable: Boolean, physicalBackIds: List<String>) {
        val suffix = if (ultraWideAvailable) " Ультраширокая камера также обнаружена." else ""
        statusText.text = if (mainCameraAvailable) "Готово. Положите телефон на гладкую поверхность.$suffix" else "Задняя камера недоступна."
    }

    override fun onCameraError(message: String) {
        statusText.text = message
        startButton.isEnabled = false
    }

    private fun showPanorama() {
        val uri = lastPanoramaUri
        if (uri == null) {
            Toast.makeText(this, "Панорама ещё не сохранена.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "image/jpeg")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (e: Exception) {
            Toast.makeText(this, "Не найдено приложение для просмотра изображения.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun savePanoramaAgain() {
        val source = lastPanorama ?: return
        val name = "AutoCapture360_saved_${System.currentTimeMillis()}.jpg"
        val uri = camera.saveJpegToGallery(source, name)
        Toast.makeText(this, if (uri != null) "Панорама сохранена." else "Не удалось сохранить панораму.", Toast.LENGTH_SHORT).show()
        if (uri != null) lastPanoramaUri = uri
    }

    private fun resetUi() {
        lastPanorama = null
        lastPanoramaUri = null
        resultText.text = ""
        showPanoramaButton.visibility = View.GONE
        savePanoramaButton.visibility = View.GONE
        newCaptureButton.visibility = View.GONE
        framesText.text = "Кадры: 0"
        angleText.text = "Угол: 0° / 360°"
        speedText.text = "Скорость: 0 °/с"
        vibrationText.text = "Вибромотор: выкл."
        statusText.text = "Готово. Положите телефон на гладкую поверхность."
    }

    private fun showSettingsDialog() {
        if (controller.isRunning()) {
            Toast.makeText(this, "Настройки доступны после остановки съёмки.", Toast.LENGTH_SHORT).show()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }
        fun field(label: String, value: String): EditText {
            val edit = EditText(this).apply {
                hint = label
                setText(value)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            box.addView(edit)
            return edit
        }
        val strength = field("Vibration strength %", settings.vibrationStrength.toString())
        val pulse = field("Pulse duration ms", settings.pulseDurationMs.toString())
        val pause = field("Pause duration ms", settings.pauseDurationMs.toString())
        val delay = field("Start delay ms", settings.startDelayMs.toString())

        val direction = Spinner(this)
        direction.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("AUTO", "CLOCKWISE", "COUNTERCLOCKWISE"))
        direction.setSelection(listOf("AUTO", "CLOCKWISE", "COUNTERCLOCKWISE").indexOf(settings.direction).coerceAtLeast(0))
        box.addView(direction)

        val frames = Spinner(this)
        frames.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("18 кадра / 20°", "20 кадров / 18°", "22 кадра / 16.36°", "24 кадра / 15°"))
        val frameValue = settings.framesPer360
        frames.setSelection(((frameValue - 18) / 2).coerceIn(0, 3))
        box.addView(frames)

        val ultra = CheckBox(this).apply {
            text = "Пытаться использовать ультраширокую камеру, если CameraX её отдельно выставляет"
            isChecked = settings.preferUltraWide
        }
        box.addView(ultra)

        AlertDialog.Builder(this)
            .setTitle("Настройки AutoCapture 360")
            .setView(box)
            .setMessage("Направление задаёт ожидаемое направление контроля; обычный вибромотор не является направленным приводом. Сила вибрации — это амплитуда API, а не гарантированный RPM.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                settings.vibrationStrength = strength.text.toString().toIntOrNull() ?: settings.vibrationStrength
                settings.pulseDurationMs = pulse.text.toString().toLongOrNull() ?: settings.pulseDurationMs
                settings.pauseDurationMs = pause.text.toString().toLongOrNull() ?: settings.pauseDurationMs
                settings.startDelayMs = delay.text.toString().toLongOrNull() ?: settings.startDelayMs
                settings.direction = direction.selectedItem.toString()
                settings.framesPer360 = listOf(18, 20, 22, 24)[frames.selectedItemPosition]
                settings.preferUltraWide = ultra.isChecked
                Toast.makeText(this, "Настройки сохранены. Если изменена камера, перезапустите предпросмотр.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onStop() {
        if (controller.isRunning()) controller.stop("Приложение ушло в background — вибрация остановлена.")
        vibration.stop()
        tracker.stop()
        super.onStop()
    }

    override fun onDestroy() {
        controller.shutdown()
        camera.shutdown()
        vibration.stop()
        tracker.stop()
        super.onDestroy()
    }
}
