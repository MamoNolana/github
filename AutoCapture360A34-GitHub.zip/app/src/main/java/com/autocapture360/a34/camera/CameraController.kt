package com.autocapture360.a34.camera

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.core.Camera
import androidx.camera.core.CameraFilter
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraController(private val context: Context) {
    interface Listener {
        fun onCameraReady(mainCameraAvailable: Boolean, ultraWideAvailable: Boolean, physicalBackIds: List<String>)
        fun onCameraError(message: String)
    }

    private val mainExecutor = ContextCompat.getMainExecutor(context)
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var preview: Preview? = null
    private var boundSelector: CameraSelector? = null
    private var listener: Listener? = null

    fun setListener(listener: Listener?) { this.listener = listener }

    fun start(previewView: PreviewView, preferUltraWide: Boolean = false) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                cameraProvider = future.get()
                bind(previewView, preferUltraWide)
            } catch (e: Exception) {
                Log.e("AutoCapture360", "ERROR camera provider", e)
                listener?.onCameraError("Не удалось открыть камеру: ${e.message}")
            }
        }, mainExecutor)
    }

    private fun bind(previewView: PreviewView, preferUltraWide: Boolean) {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        val available = provider.availableCameraInfos
        val back = available.filter { info ->
            Camera2CameraInfo.from(info).getCameraCharacteristic(android.hardware.camera2.CameraCharacteristics.LENS_FACING) == android.hardware.camera2.CameraMetadata.LENS_FACING_BACK
        }
        val ids = back.map { Camera2CameraInfo.from(it).cameraId }.distinct()
        val ultraAvailable = back.any { focalLengths(it).minOrNull()?.let { f -> f < 3.2f } == true }
        listener?.onCameraReady(back.isNotEmpty(), ultraAvailable, ids)

        val selector = if (preferUltraWide && ultraAvailable) {
            ultraWideSelector()
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }

        preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setJpegQuality(95)
            .build()

        try {
            camera = provider.bindToLifecycle(
                context as androidx.lifecycle.LifecycleOwner,
                selector,
                preview,
                imageCapture
            )
            boundSelector = selector
        } catch (e: Exception) {
            Log.e("AutoCapture360", "ERROR camera bind", e)
            listener?.onCameraError("Не удалось подключить камеру: ${e.message}")
        }
    }

    private fun focalLengths(info: CameraInfo): FloatArray {
        val lengths = Camera2CameraInfo.from(info).getCameraCharacteristic(
            android.hardware.camera2.CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS
        )
        return lengths ?: floatArrayOf(Float.MAX_VALUE)
    }

    private fun ultraWideSelector(): CameraSelector {
        return CameraSelector.Builder()
            .addCameraFilter(CameraFilter { infos ->
                val backs = infos.filter {
                    val facing = Camera2CameraInfo.from(it).getCameraCharacteristic(
                        android.hardware.camera2.CameraCharacteristics.LENS_FACING
                    )
                    facing == android.hardware.camera2.CameraMetadata.LENS_FACING_BACK
                }
                val candidate = backs.minByOrNull { focalLengths(it).minOrNull() ?: Float.MAX_VALUE }
                if (candidate != null) listOf(candidate) else infos
            })
            .build()
    }

    fun captureToCache(callback: (File) -> Unit, onError: (Throwable) -> Unit) {
        val capture = imageCapture ?: run {
            onError(IllegalStateException("ImageCapture not ready")); return
        }
        val file = File.createTempFile("AC_", ".jpg", context.cacheDir)
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.targetRotation = Surface.ROTATION_0
        Log.d("AutoCapture360", "CAPTURE_START ${file.name}")
        capture.takePicture(options, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                Log.d("AutoCapture360", "CAPTURE_DONE ${file.absolutePath}")
                mainExecutor.execute { callback(file) }
            }
            override fun onError(exception: ImageCaptureException) {
                Log.e("AutoCapture360", "ERROR image capture", exception)
                mainExecutor.execute { onError(exception) }
            }
        })
    }

    fun saveJpegToGallery(source: File, displayName: String): android.net.Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoCapture360")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        try {
            resolver.openOutputStream(uri)?.use { out -> FileInputStream(source).use { it.copyTo(out) } }
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            Log.e("AutoCapture360", "ERROR save gallery", e)
            return null
        }
    }

    fun saveBytesToGallery(bytes: ByteArray, displayName: String): android.net.Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AutoCapture360")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        try {
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
            if (Build.VERSION.SDK_INT >= 29) {
                resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            }
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            return null
        }
    }

    fun shutdown() {
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        cameraExecutor.shutdownNow()
    }
}
