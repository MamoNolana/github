# Keep OpenCV native bridge and Java wrappers used through reflection.
-keep class org.opencv.** { *; }
# Keep CameraX internal metadata classes that can be queried by Camera2 interop.
-dontwarn org.opencv.**
