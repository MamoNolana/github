# AutoCapture 360 A34

Нативное Kotlin-приложение для Samsung Galaxy A34 5G. Телефон кладётся экраном вверх на гладкую ровную поверхность и пользователь запускает один цикл кнопкой `360°`. Приложение управляет вибромотором через Android Vibrator API, измеряет фактическое вращение по гироскопу/акселерометру, при наличии мягко использует магнитометр, делает кадры по углу и склеивает их через OpenCV Stitcher.

## Важное ограничение

Обычный встроенный вибромотор телефона не является управляемым сервоприводом. Android позволяет задавать вибрационный waveform/amplitude, но не гарантирует RPM, направление вращения или то, что телефон вообще начнёт вращаться на конкретной поверхности. Поэтому профиль вибрации здесь является экспериментальным параметром, а решение о съёмке принимает `RotationTracker` по фактическому движению.

## Сборка

```bash
./gradlew assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Release:

```bash
./gradlew assembleRelease
```

## Установка по USB

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Архитектура

- `MainActivity` — экран и жизненный цикл.
- `A34VibrationController` — waveform, сила, профили, безопасная отмена.
- `RotationTracker` — gyro + gravity projection + мягкая магнитометрическая коррекция, направление, угол, скорость.
- `AutoCaptureController` — state machine 360°, стабилизация, интервалы, таймаут 30 с.
- `CameraController` — CameraX preview/capture, основная задняя камера и попытка выбора ultrawide при отдельной экспозиции CameraX.
- `PanoramaStitcher` — OpenCV `Stitcher.PANORAMA` с registration/seam/compositing resolutions и wave correction. Встроенный OpenCV pipeline выполняет feature matching, camera estimation/homography, warping, seam handling, exposure compensation и blending.
- `CalibrationController` / `CalibrationActivity` — 4 тестовых профиля и поиск профиля с наименьшей относительной вариативностью измеренной скорости.
- `DiagnosticsActivity` — сырые значения трёх датчиков и текущая кинематика.
- `SettingsManager` — сохранение настроек.

## Профили

1. ON 100 ms / OFF 20 ms
2. ON 150 ms / OFF 20 ms
3. ON 200 ms / OFF 30 ms
4. ON 80 ms / OFF 10 ms

Это не гарантированные значения для вращения A34; их нужно измерять на реальной поверхности.

## Галерея

Исходные кадры сохраняются как `AC_000.jpg`, `AC_001.jpg`, ... в `Pictures/AutoCapture360/`. Панорама получает имя `AutoCapture360_YYYYMMDD_HHMMSS.jpg`.

## GitHub Actions

`.github/workflows/build.yml` устанавливает JDK 17 и Android SDK 36, собирает debug/release и прикладывает APK как artifacts.

## Практический тест

Перед полным циклом откройте `Калибровка A34`, протестируйте все четыре профиля на той же поверхности, где будет выполняться съёмка. Никаких гарантий автоматического оборота быть не может без механического привода/насадки: приложение диагностирует и использует только реально обнаруженное вращение.
