@echo off
setlocal
set GRADLE_VERSION=9.6.1
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME=%GRADLE_USER_HOME%\autocapture360\gradle-%GRADLE_VERSION%
set DIST_DIR=%GRADLE_USER_HOME%\autocapture360
set ZIP=%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%DIST_DIR%' -Force"
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
